
import { Component } from '@angular/core';
import { Platform, NavController, NavParams } from 'ionic-angular';
//import { Platform, Nav } from 'ionic-angular';

import { OrgSettingsPage } from '../org-settings/org-settings';
import { QpiItemSettingsPage } from '../qpi-item-settings/qpi-item-settings';
import { QuotationPage } from '../quotation/quotation';
import { PoPage } from '../po/po';
import { TaxPage } from '../tax/tax';


@Component({
  selector: 'page-menu-page',
  templateUrl: 'menu-page.html'
})
export class MenuPagePage {
	//@ViewChild('myNav') nav: Nav;
	//rootPage: any = OrgSettingsPage;
	pages: Array<{title: string, component: any, img: any}>;
	constructor(
	public platform: Platform,
	public navCtrl: NavController
	) {

		// set our app's pages
		this.pages = [
			{ title: 'Organisation Settings', component: OrgSettingsPage, img: 'assets/img/OrgSetting.png' },
			{ title: 'QPI Item Settings', component: QpiItemSettingsPage,img: 'assets/img/QPISetting.png' },
			{ title: 'Quotation', component: QuotationPage, img: 'assets/img/Quotation.png' },
			{ title: 'PO', component: PoPage, img: 'assets/img/PO.png' },
			{ title: 'Tax', component: TaxPage,img: 'assets/img/Tax.png' }
		];
	}

     

	ionViewDidLoad() {
		console.log('ionViewDidLoad MenuPagePage');
	}


	openPage(page) {
		// close the menu when clicking a link from the menu
		//this.menu.close();
		// navigate to the new page if it is not the current page
		//this.nav.setRoot(page.component);
		this.navCtrl.push(page.component);
	}





}